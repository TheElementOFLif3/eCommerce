package com.example.servlet;

import com.example.dao.UserDao;
import com.example.entity.User;
import com.example.helper.FactoryProvider;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.hibernate.SessionFactory;

import java.io.IOException;
import java.io.PrintWriter;

public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {


            // Login form data
            String email = request.getParameter("email");
            String password = request.getParameter("password");

            // Authenticating user
            SessionFactory sessionFactory = FactoryProvider.getFactory();
            UserDao userDao = new UserDao(sessionFactory);
            User user = userDao.getUserByEmailAndPassword(email, password);

            HttpSession httpSession = request.getSession();

            if (user == null) {
                httpSession.setAttribute("message", "Invalid details. Please try again.");
                response.sendRedirect("login.jsp");
                return;
            } else {
                out.println("<h1>Welcome " + user.getUserName() + "</h1>");

                    // Login
                httpSession.setAttribute("current-user", user);

                if (user.getUserType().equals("admin")) {
                    // admin.jsp
                    response.sendRedirect("admin.jsp");
                } else if (user.getUserType().equals("normal")) {
                    // normal.jsp
                    response.sendRedirect("index.jsp?category=all");
                } else {
                    out.println("We have not identified user type");
                }

            }
        }
    }
}
